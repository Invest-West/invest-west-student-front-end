require('dotenv').config();

const firebase = require('firebase');
const schedule = require('node-schedule');

const USERS_CHILD = "Users";
const PITCHES_CHILD = "Pitches";
const PRIMARY_OFFERS_CHILD = "PrimaryOffers";
const DEALS_CHILD = "Deals";

const PITCH_STATUS_ALL = 0;
const PITCH_STATUS_ON_GOING = 1;
const PITCH_STATUS_ACCEPTED = 2;
const PITCH_STATUS_REJECTED = 3;
// when the admin accepts a pitch, its status will change to this state (pitch accepted and waiting for primary offer to be created)
// when the issuer creates a primary offer, the pitch's status will change to PITCH_STATUS_ACCEPTED
const PITCH_STATUS_ACCEPTED_CREATE_PRIMARY_OFFER = 4;
// this status means the pitch has expired but admin has not accepted or rejected it
const PITCH_STATUS_WAITING_FOR_ADMIN = 5;

const PRIMARY_OFFER_ALL = 0;
const PRIMARY_OFFER_ON_GOING = 1;
// this status means the primary has failed because it hasn't reached its target
// thus, it cannot become a deal
const PRIMARY_OFFER_FAILED = 2;

// this status means the primary offer has expired and reached its target
// but all deals have not been confirmed. at this stage, all the investors that pledged this offer must work with the issuer offline
// all the paper progress must be checked offline by the admin before this primary offer can be considered a successful one
// the investor pledged a primary offer (the primary offer hasn't ended yet)
const DEAL_ON_GOING = 11;
// the deal has been confirmed successful by the admin (when offline work with this investor and other investors succeeded) --> close all deals
const DEAL_SUCCESSFUL = 22;
// the deal has been considered a failure by the admin (when offline work with this investor or other investors did not succeed) --> close all deals
const DEAL_FAILED = 33;
// the deal has not been confirmed successful or failed by the admin. But the deal between this investor and the issuer has been successful.
const DEAL_NEGOTIATION_SUCCESSFUL = 44;
// the deal has not been confirmed successful or failed by the admin. But the deal between this investor and the issuer has been unsuccessful.
const DEAL_NEGOTIATION_FAILED = 55;

/** Initialize firebase to use with node js */
const config = {
    apiKey: process.env.REACT_APP_FIREBASE_KEY,
    authDomain: "invest-west.firebaseapp.com",
    databaseURL: "https://invest-west.firebaseio.com",
    projectId: "invest-west",
    storageBucket: "invest-west.appspot.com",
    messagingSenderId: "648492737211"
};
firebase.initializeApp(config);
// sign in with admin account so that the server can perform action on the database
firebase.auth().signInWithEmailAndPassword(process.env.REACT_APP_ADMIN_EMAIL, 'InvestWestGroup1@')
    .then(function() {
        checkExpiredPitches();
        checkExpiredPrimaryOffers();
    })
    .catch(function(error) {
        console.log(error);
    });

/**
 * This function is used to check for expired pitches that have not been accepted or rejected by admin
 */
function checkExpiredPitches () {

    const firebaseDB = firebase.database();

    // schedule job at 00:00:00 every day
    schedule.scheduleJob('0 0 0 * * *', () => {
        loadPitches()
            .then(pitches => {
                pitches.forEach(pitch => {
                    // if the on-going pitch has expired in time
                    if (dateDiff(pitch.dateExpired) === -1) {
                        firebaseDB.ref(PITCHES_CHILD)
                            .child(pitch.id)
                            .child("status")
                            .set(PITCH_STATUS_WAITING_FOR_ADMIN); // change pitch status to 5 - waiting for admin to check
                    }
                });
            })
            .catch(error => {
                console.log(error);
            });
    });
}

/**
 * This function is used to check for expired primary offers
 */
function checkExpiredPrimaryOffers () {

    const firebaseDB = firebase.database();

    // schedule job at 00:00:00 every day
    schedule.scheduleJob('0 0 0 * * *', () => {
        loadPrimaryOffers()
            .then(primaryOffers => {
                primaryOffers.forEach(primaryOffer => {
                    // if the on-going pitch has expired in time
                    if (dateDiff(primaryOffer.expiredDate) === -1) {
                        // check if the primary offer has reached its target or not
                        if (getPledges(primaryOffer).money >= parseFloat(primaryOffer.fundTarget)) {
                            // fund target has reached
                            firebaseDB.ref(PRIMARY_OFFERS_CHILD)
                                .child(primaryOffer.primaryOfferID)
                                .child("status")
                                // change primary offer status to 11 (DEAL_ON_GOING) - issuer and investors start working offline
                                .set(DEAL_ON_GOING)
                                .then(function() {

                                    const pledges = primaryOffer.pledges;
                                    if (pledges) {
                                        // create deals for each investor involved
                                        for (let investorID in pledges) {
                                            firebaseDB
                                                .ref(USERS_CHILD)
                                                .child(investorID)
                                                .child(DEALS_CHILD)
                                                .child(primaryOffer.primaryOfferID)
                                                .set(primaryOffer.issuerID);
                                        }
                                    }
                                });
                        }
                        else {
                            // fund target has not reached
                            firebaseDB.ref(PRIMARY_OFFERS_CHILD)
                                .child(primaryOffer.primaryOfferID)
                                .child("status")
                                .set(PRIMARY_OFFER_FAILED); // change primary offer status to 3 - primary offer has failed
                        }
                    }
                });
            })
            .catch(error => {
                console.log(error);
            });
    });
}

/**
 * This function is used to calculate date difference
 *
 * @param milliseconds
 * @returns {string|number}
 */
function dateDiff (milliseconds) {
    const currentDate = new Date();
    if (milliseconds - currentDate.getTime() < 0) {
        return -1;
    }
    const dateDiff = Math.abs(milliseconds - currentDate.getTime()); // difference
    return (dateDiff / (24 * 60 * 60 * 1000)).toFixed(0); //Convert values days and return value
}

/**
 * Load all on-going pitches
 *
 * @returns {Promise<any>}
 */
function loadPitches () {
    const db = firebase.database();

    let allPitches = [];

    return new Promise((resolve, reject) => {
        db
            .ref(PITCHES_CHILD)
            .orderByChild('status')
            .equalTo(PITCH_STATUS_ON_GOING)
            .once('value', snapshots => {
                if (!snapshots.exists() || !snapshots) {
                    return reject({error: "Snapshot null"});
                }

                snapshots.forEach(snapshot => {
                    let pitch = snapshot.val();
                    pitch.id = snapshot.key;
                    allPitches.push(pitch);
                });
                return resolve(allPitches);
            });
    });
}

/**
 * Load all on-going primary offers
 *
 * @returns {Promise<any>}
 */
function loadPrimaryOffers () {
    const db = firebase.database();

    let allPrimaryOffers = [];

    return new Promise((resolve, reject) => {
        db
            .ref(PRIMARY_OFFERS_CHILD)
            .orderByChild('status')
            .equalTo(PRIMARY_OFFER_ON_GOING)
            .once('value', snapshots => {
                if (!snapshots.exists() || !snapshots) {
                    return reject({error: "Snapshot null"});
                }

                snapshots.forEach(snapshot => {
                    let primaryOffer = snapshot.val();
                    primaryOffer.primaryOfferID = snapshot.key;
                    allPrimaryOffers.push(primaryOffer);
                });
                return resolve(allPrimaryOffers);
            });
    });
}

/**
 * This function is used to check for pledges of a primary offer
 *
 * @param primaryOffer
 * @returns {{money: number, pledges: Array}}
 */
function getPledges (primaryOffer) {
    const pledgesObj = primaryOffer.pledges;

    let pledgedMoney = 0;
    let pledges = [];

    if (!pledgesObj) {
        return {money: pledgedMoney, pledges: pledges};
    }

    for (let investorID in pledgesObj) {
        let pledge = pledgesObj[investorID];
        pledgedMoney += parseFloat(pledge.moneyPledge);

        pledge.investorID = investorID;
        pledges.push(pledge);
    }

    return {money: pledgedMoney, pledges: pledges};
}
