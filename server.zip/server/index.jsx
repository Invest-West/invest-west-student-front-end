const express = require('express');
const cors = require('cors');
const sgMail = require('@sendgrid/mail');
const axios = require('axios/index');

// require this module to load variables in the .env file
require('dotenv').config();

// perform automatic checking for pitches and primary offers
require('./firebaseSchedule.jsx');

const app = express();
app.use(cors());

// Listen for post request (email post request) from the client
app.post(process.env.REACT_APP_SERVER_SMTP_PATH, (req, res) => {

    const EMAIL_INVITATION = 1;
    const EMAIL_PITCH_ACCEPTED = 2;
    const EMAIL_PITCH_REJECTED = 3;

    const TYPE_INVESTOR = 1;
    const TYPE_ISSUER = 2;
    
    // Get variables from query string
    const { recipient, name, usertype, emailtype, refID } = req.query;

    let userType = null;
    switch (parseInt(usertype)) {
        case TYPE_INVESTOR:
            userType = 'Investor';
            break;
        case TYPE_ISSUER:
            userType = 'Issuer';
            break;
        default:
            break;
    }

    let msg = null;
    switch (parseInt(emailtype)) {
        case EMAIL_INVITATION:
            msg = {
                to: recipient,
                from: process.env.REACT_APP_ADMIN_EMAIL,
                templateId: 'd-2d30bd5d5c094f8a98061ae1fee0ed85',
                dynamic_template_data: {
                    name: name,
                    usertype: userType,
                    signuplink: `${process.env.REACT_APP_SIGNIN_URL}/${refID}`
                }
            }
            break;
        case EMAIL_PITCH_ACCEPTED:
            msg = {
                to: recipient,
                from: process.env.REACT_APP_ADMIN_EMAIL,
                templateId: 'd-7976566abe8a4c41bb99be5af8594cb1',
                dynamic_template_data: {
                    name: name
                }
            }
            break;
        case EMAIL_PITCH_REJECTED:
            msg = {
                to: recipient,
                from: process.env.REACT_APP_ADMIN_EMAIL,
                templateId: 'd-1c813fc286fe450cb3c6f7eeaaae54e5',
                dynamic_template_data: {
                    name: name
                }
            }
            break;
        default:
            break;
    }

    // set api key for SendGrid
    sgMail.setApiKey(process.env.REACT_APP_SENDGRID_API_KEY);
    // Send email
    sgMail.send(msg)
        .then(msg => {
            console.log("Success");
            res.send(msg);
        })
        .catch(error => {
            console.log(error);
            res.send(error);
        });
});

// Listen for get request for find addresses
app.get(process.env.REACT_APP_SERVER_GET_ADDRESS_PATH, (req, res) => {
    const { postcode } = req.query;
    console.log(postcode);
    let addressQuery = `https://api.getAddress.io/find/${postcode}?api-key=${process.env.REACT_APP_GET_ADDRESS_API_KEY}&sort=True&format=True`;

    axios.get(addressQuery)
    .then(result => {
        console.log(result.data.addresses);
        res.send(result.data.addresses);
    })
    .catch(error => {
        console.log(error);
        res.send(error);
    });
});

// Wake for server up to listen for requests from React client
app.listen(process.env.REACT_APP_SERVER_PORT, 
() => console.log(`Server starts running on port ${process.env.REACT_APP_SERVER_PORT}`));